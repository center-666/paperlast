# 第一篇论文：SSCD v3（共同随机数 + 高维 Watson + 风险可接受选参）

研究日期：2026-11-22。原始基线是 `center-666/paperlast` commit `32d27189a220ce28893bb68ac9b97cf85abeee8c`。本包**没有**修改或重写历史 `iid` 锁定、旧共 G、6条 A0 攻击、奇偶检测器、任何先前最终测试结果；**不属于第二篇可信事件/量化恢复论文**。

## 一、审阅已有 v2 后确立的事实

已直接读取 `V2_RESULTS.md`、`locked_selection.json`、`selector_v2.py`、`run_development.py`、`run_final_evaluation.py`。v2 的12场景×256条开发路径锁定 iid，最差负耦合单场景的同时上界为 `+0.0312009007%`；在各场景等权下，旧开发数据的 **负耦合相对 iid 点估计平均约 −0.5813235%**。此外，旧固定候选在独立的12×512测试路径上仍有改进，却**不能**用于追溯修改锁定值。上述仅为旧数据的事后解释，不是 v3 新选参成果。

重要方法学问题：原 v2 在每一个场景要求“严格改善”，因此两个本来几乎没有耦合敏感性的场景可以阻止一项在多数场景有实用收益的候选。增强版考虑把“每个场景不应有超过预登记容忍度的损失”与“总体应具有足够大收益”分开，**不是**事后把原论文的 v2 iid 锁定改成负耦合。

## 二、二维 Signed Watson 精确同分布逆变换

对于 `u_t=(cos alpha_t, sin alpha_t)` 与转移核 `p(u'|u)∝exp(theta (u^T u')²)`，令 `phi=2(alpha_{t+1}-alpha_t) mod 2π`，则

\[
 f_{\theta}(\phi)=\frac{\exp[(\theta/2)\cos\phi]}{2\pi I_0(\theta/2)}.
\]

给定同一个潜在 `U~Unif(0,1)`，用 `phi=F_theta^{-1}(U)`，并用独立公平二值 `B` 在两个合法角度分支间选取 `alpha'=alpha+phi/2+πB`，则目标方向转移核与原 `replay.attack_watermarks` **同分布**（不承诺逐样本相等）。再独立抽取 `.5*chi2_2` 的半径平方，任意单拍都有 `beta_t~N(0,.5 I_2)`，`M_t=.5 I+beta_t beta_t^T`。

简化指标：

\[
 \zeta_2(\theta)=\frac{I_1(\theta/2)}{I_0(\theta/2)},\qquad
 \mathcal I_2(\theta)=\frac{\theta}{2}\zeta_2(\theta)-\log I_0(\theta/2).
\]

**注意**：这是相邻秘密水印矩阵的统计相关信息成本，并不等于窃听者观察编码载荷之后获得的秘密条件互信息，更不构成密码学不可预测性证明。

`watson_crn.py` 使用带符号 Fourier CDF 的逆变换，同一场景的 iid/负/正候选共享初始方向、半径、均匀分位数和方向分支，场景之间独立。原来的拒绝采样代码保持不变。逆变换经过 `theta∈[-2,2]` 和 CDF 残差 `≤2e-14` 的数值检查；只对验证过的 `|theta|≤2.1` 提供实现。

### 人工门控演示模型中的方差验证（不是50节点结果）

- 8组独立重采样，每组4096条物理路径；同一二维攻击、噪声和门控规则；对照仅改变候选水印之间是否共享转移驱动随机数。
- 独立转移的配对损失平均 SE：`0.00012028275`；CRN 采样平均 SE：`0.00010749312`。
- 平均 SE 减少约 `10.633%`；以 SE 比估算，相同精度需要约 `0.7987` 倍样本，即相当于独立转移设计约 `1.252` 倍有效样本数。**不是**估计 MSE 降低10%。
- 两种采样设计的试验平均风险差接近但不完全一致；单批 Monte Carlo 采样噪声可以造成差异。其他系统/原50节点上的方差降低幅度仍未知。

## 三、高维 m>=2：倾斜 Beta 表示与信息预算不对称

均匀方向下 `Z=(u_t^T u_{t+1})²~Beta(1/2,(m-1)/2)`，Watson 转移相当于该标量的指数倾斜：

\[
 f_{m,\theta}(z)=\frac{e^{\theta z} f_{m,0}(z)}{{}_1F_1(1/2;m/2;\theta)}.
\]

抽取 `Z` 的逆 CDF、独立正负号 `S`、当前方向正交补内均匀 `v` 后，`u'=S sqrt(Z) u+sqrt(1-Z) v`。若初始 `u` 为均匀方向，未来方向的单拍边缘持续均匀，配合独立 `q chi²_m` 半径给出 `beta_t~N(0,q I_m)`。

\[
 \zeta_m=\frac{m\,E[Z]-1}{m-1}, \quad
 I_m(\theta)=\theta E[Z]-\log {}_1F_1(1/2;m/2;\theta).
\]

**高维结构性发现**：二维时 Beta(1/2,1/2) 的中心对称性使 `I_2(theta)=I_2(-theta)`；m>2 时一般不对称。对相同相邻 MI 预算 `0.1 nats`，理论根为：

| m | 负 theta | 正 theta |
|---:|---:|---:|
|2|−1.315237|+1.315237|
|3|−1.728334|+1.413913|
|4|−2.192337|+1.601938|
|6|−3.168649|+2.026114|
|10|−5.182614|+2.906290|

高维正负耦合比较必须**按相同 MI 预算分别选 θ**，不能直接比较 `±θ`。`watson_nd.py` 对整数 `m>=2` 提供通用倾斜 Beta 逆变换，目前在 `|theta|<=6` 下检查了 m=2,3,4,6,10 的逆CDF数值残差（典型 `<2e-12`）；实际多维共 G / 奇偶检测性能**尚未执行**，仅完成采样律与 Gaussian 单拍统计的合成验证。

## 四、v3 门控后最终风险选参：风险容忍与平均收益分离

对已经预先登记的 `S` 个场景，定义相对风险 `Delta_{s,theta}=(E J_{s,theta}-E J_{s,iid})/E J_{s,iid}`，其中 `J` 始终使用**最终共 G 输出的相同 MSE**，不使用 KL 替代。

v3 预备评价规则（在**新的**开发/测试集上实施，不能 retroactively 复验 v2）：

\[
 \begin{split}
 &\text{for all }s:\quad \operatorname{UCB}_{s,\theta}(\Delta)\le\varepsilon,\\
 &\operatorname{UCB}_{\theta}\bigg(\frac1{|S|}\sum_s\Delta_{s,\theta}\bigg)<-\gamma,\\
 &I_m(\theta)\le I_{\max}.
 \end{split}
\]

建议作为新设计注册起点：`epsilon=0.001` 即每场景最多 `0.1%` 相对退化；`gamma=0.001` 即跨场景至少 `0.1%` 相对改善；`Imax=0.1 nats/step`。**这些阈值在看到旧数据后提出，不能对旧 v2 终验使用，不代表已完成前瞻性预注册。** 必须说明每场景退化容忍来自工程指标和决策成本，不能根据下一次结果再调整。若无候选同时满足，退回 iid。

`selector_v3.py` 使用配对 t 分子界和 iid 分母上下界获得逐场景一侧上界；跨场景平均风险差采用配对 delta-method 影响函数（包含分子、分母协方差），再用 Satterthwaite t 近似计算上置信界。保守分配总 α=0.05：一半用于所有候选×场景非劣界，另一半用于候选间平均收益界，避免显著性选参后混用测试数据。路径损失可能偏态、时序相关；**所得不是分布无关的有限样本证书**。

该优化规则的含义是允许对少数并不敏感的场景出现工程可接受的极小退化，但确保其相对风险有显式控制，并要求跨场景能取得有意义的总收益。与 v2 的“每场景必有统计显著正改善”相比，这是一个**新的研究选择**，不是 v2 的 Bug 修复。

## 五、工程程序及已经执行的测试

| 文件 | 作用 | 此轮执行情况 |
|---|---|---|
| `watson_crn.py` | m=2 精确目标律共同分位数采样及原水印解码攻击 | CDF/KS/协方差测试已过 |
| `watson_nd.py` | m>=2 的指数倾斜 Beta 多维理论与采样 | CDF/marginal/不同维数测试已过 |
| `demo_variance.py` | 独立二维门控演示模型的CRN效率验证 | 8×4096条合成轨迹完成 |
| `selector_v3.py` | 风险容忍+总体收益的开发集选参规则 | 合成正例、退回 iid 测试已过 |
| `run_crn_development.py` | 读取真实冻结50节点共G源，独立开发并锁定 | dry-run与**模拟后端**接口烟测通过；真实50节点未运行 |
| `run_crn_final.py` | 锁定参数只读、独立健康校准与12场景测试 | dry-run与**模拟后端**完整接口测试通过；真实50节点未运行 |
| `test_watson.py`,`test_adapter.py`,`test_final_adapter.py` | 数值与工程接口回归 | 全部通过 |

使用方式：将本目录置于完整 `paperlast` 根目录下，并保证旁边有三个历史目录 `paper1_common_g50_gain_acceptance_20261121`, `paper1_50node_tv_gate_theory_20261121`, `paper1_sscd_dev_protocol_20261122`。需要 `numpy scipy mpmath`；使用真实原始配置时会调用已有文件SHA源保护。

```bash
# 仅运行可在当前容器验证的合成与数值测试
python paper1_sscd_commonrandom_20261122/test_watson.py
python paper1_sscd_commonrandom_20261122/demo_variance.py
python paper1_sscd_commonrandom_20261122/selector_v3.py
python paper1_sscd_commonrandom_20261122/test_adapter.py
python paper1_sscd_commonrandom_20261122/test_final_adapter.py

# 50节点协议 dry-run，不执行物理仿真
python paper1_sscd_commonrandom_20261122/run_crn_development.py
python paper1_sscd_commonrandom_20261122/run_crn_final.py

# 下一批**全新**50节点开发数据（不会覆盖旧v2归档）
python paper1_sscd_commonrandom_20261122/run_crn_development.py --execute --calibration 512 --paths 256 --seed 2026120302

# 参数锁定之后，绝对不能根据测试候选结果再改变参数
python paper1_sscd_commonrandom_20261122/run_crn_final.py --execute --calibration 512 --paths 512 --seed 2026120705
```

`run_crn_development.py` 只写 `crn_development_losses.json`, `crn_locked_selection.json` 与 `crn_development_manifest.json`；`run_crn_final.py` 只读取锁定的参数并在另一个命名空间产生独立结果、heldout健康FPR、路径NPZ与静态已知六边oracle。两者都不会改变之前所有文件。路径中的随机数是实验标签，不表示运行日期。

## 六、下一步应被拒绝的论文主张

1. 不能说**已证明**新 v3 在50节点优于固定负耦合；实际新50节点开发/终验尚未运行。
2. 不能把采样共同随机数的 SE 减少说成物理状态 MSE 改善，更不能将采样算法本身包装为新的安全水印机制。
3. 不得把 12 个方向/起点场景说成未知攻击**支持集**；六条攻击链路仍然固定。
4. 现有共 G 仍为 n=m=2 的50节点系统；高维采样合法≠高维共 G 闭环安全估计已验收。
5. 不得在未验证攻击者当前水印知识、同步安全、窃听条件信息前宣称互信息约束等于保密性。
6. 已知六条边永久删除的 oracle 仍是强基线，必须报告；进一步比较需要基于不泄露真实未来支持集的现实信息权限。

## 七、研究决策

**建议先用本包的新独立开发集测量 CRN 在原50节点实际减少多少差值SE、是否能前瞻性选出负耦合，并将自动选参和固定负耦合进行真正独立比较。** 若 v3 仍锁定 iid，不应强行修改超参或复用测试路径，应报告失败并把第一篇的核心收束为“负耦合水印设计及其估计保护作用”而不是自动最优设计。然后另立高维状态/测量模型与未知支持集的严格对照实验。
